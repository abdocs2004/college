package college;

import college.db.DatabaseConnection;
import java.sql.Connection;
import java.sql.SQLException;

public class CollegeApp {
    public static void main(String[] args) {
        try (Connection conn = DatabaseConnection.getConnection()) {
            System.out.println("Connection to CollegeDB successful!");
        } catch (SQLException e) {
            System.err.println("Connection failed: " + e.getMessage());
        }
    }
}
