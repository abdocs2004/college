package college.gui.awt;

import college.db.DatabaseConnection;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;

public class DepartmentForm extends Frame implements ActionListener {
    TextField txtLocation, txtDName, txtHead;
    Label lblLocation, lblDName, lblHead;
    Button btnInsert, btnUpdate, btnDelete, btnSearch, btnNext;
    TextArea tableDisplay;

    DepartmentForm() {
        setLayout(null);
        setBounds(0, 0, 500, 400);
        setTitle("Department Form");

        lblLocation = new Label("Location:");
        lblLocation.setBounds(50, 50, 80, 25);
        txtLocation = new TextField();
        txtLocation.setBounds(150, 50, 150, 25);

        lblDName = new Label("Dept Name:");
        lblDName.setBounds(50, 90, 80, 25);
        txtDName = new TextField();
        txtDName.setBounds(150, 90, 150, 25);

        lblHead = new Label("Head:");
        lblHead.setBounds(50, 130, 80, 25);
        txtHead = new TextField();
        txtHead.setBounds(150, 130, 150, 25);

        btnInsert = new Button("Insert");
        btnInsert.setBounds(50, 170, 60, 30);
        btnUpdate = new Button("Update");
        btnUpdate.setBounds(120, 170, 60, 30);
        btnDelete = new Button("Delete");
        btnDelete.setBounds(190, 170, 60, 30);
        btnSearch = new Button("Search");
        btnSearch.setBounds(260, 170, 60, 30);
        btnNext = new Button("Next");
        btnNext.setBounds(400, 50, 60, 30);

        tableDisplay = new TextArea();
        tableDisplay.setBounds(50, 210, 400, 150);
        tableDisplay.setEditable(false);

        add(lblLocation);
        add(txtLocation);
        add(lblDName);
        add(txtDName);
        add(lblHead);
        add(txtHead);
        add(btnInsert);
        add(btnUpdate);
        add(btnDelete);
        add(btnSearch);
        add(btnNext);
        add(tableDisplay);

        btnInsert.addActionListener(this);
        btnUpdate.addActionListener(this);
        btnDelete.addActionListener(this);
        btnSearch.addActionListener(this);
        btnNext.addActionListener(this);

        loadData();
        setVisible(true);

        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent we) {
                System.exit(0);
            }
        });
    }

    private void loadData() {
        tableDisplay.setText("");
        try (Connection conn = DatabaseConnection.getConnection()) {
            String sql = "SELECT * FROM Department";
            PreparedStatement stmt = conn.prepareStatement(sql);
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                String location = rs.getString("Location");
                String dName = rs.getString("D_Name");
                String head = rs.getString("Head");
                tableDisplay.append(location + "\t" + dName + "\t" + head + "\n");
            }
        } catch (SQLException e) {
            showMessage("Error loading data: " + e.getMessage());
        }
    }

    private void clearFields() {
        txtLocation.setText("");
        txtDName.setText("");
        txtHead.setText("");
    }

    @Override
    public void actionPerformed(ActionEvent ae) {
        if (ae.getSource() == btnInsert) {
            String location = txtLocation.getText();
            String dName = txtDName.getText();
            String head = txtHead.getText();

            if (location.isEmpty() || dName.isEmpty()) {
                showMessage("Please fill all required fields");
                return;
            }

            try (Connection conn = DatabaseConnection.getConnection()) {
                String sql = "INSERT INTO Department (Location, D_Name, Head) VALUES (?, ?, ?)";
                PreparedStatement stmt = conn.prepareStatement(sql);
                stmt.setString(1, location);
                stmt.setString(2, dName);
                stmt.setString(3, head.isEmpty() ? null : head);
                stmt.executeUpdate();
                showMessage("Department inserted successfully!");
                loadData();
                clearFields();
            } catch (SQLException e) {
                showMessage("Error inserting department: " + e.getMessage());
            }
        } else if (ae.getSource() == btnUpdate) {
            String location = txtLocation.getText();
            String dName = txtDName.getText();
            String head = txtHead.getText();

            if (dName.isEmpty()) {
                showMessage("Please enter Department Name to update");
                return;
            }

            try (Connection conn = DatabaseConnection.getConnection()) {
                String sql = "UPDATE Department SET Location = ?, Head = ? WHERE D_Name = ?";
                PreparedStatement stmt = conn.prepareStatement(sql);
                stmt.setString(1, location);
                stmt.setString(2, head.isEmpty() ? null : head);
                stmt.setString(3, dName);
                int rows = stmt.executeUpdate();
                if (rows > 0) {
                    showMessage("Department updated successfully!");
                    loadData();
                    clearFields();
                } else {
                    showMessage("Department not found!");
                }
            } catch (SQLException e) {
                showMessage("Error updating department: " + e.getMessage());
            }
        } else if (ae.getSource() == btnDelete) {
            String dName = txtDName.getText();

            if (dName.isEmpty()) {
                showMessage("Please enter Department Name to delete");
                return;
            }

            try (Connection conn = DatabaseConnection.getConnection()) {
                String sql = "DELETE FROM Department WHERE D_Name = ?";
                PreparedStatement stmt = conn.prepareStatement(sql);
                stmt.setString(1, dName);
                int rows = stmt.executeUpdate();
                if (rows > 0) {
                    showMessage("Department deleted successfully!");
                    loadData();
                    clearFields();
                } else {
                    showMessage("Department not found!");
                }
            } catch (SQLException e) {
                showMessage("Error deleting department: " + e.getMessage());
            }
        } else if (ae.getSource() == btnSearch) {
            String dName = txtDName.getText();

            if (dName.isEmpty()) {
                loadData();
                return;
            }

            tableDisplay.setText("");
            try (Connection conn = DatabaseConnection.getConnection()) {
                String sql = "SELECT * FROM Department WHERE D_Name = ?";
                PreparedStatement stmt = conn.prepareStatement(sql);
                stmt.setString(1, dName);
                ResultSet rs = stmt.executeQuery();
                if (rs.next()) {
                    String location = rs.getString("Location");
                    String head = rs.getString("Head");
                    tableDisplay.append(location + "\t" + dName + "\t" + head + "\n");
                } else {
                    showMessage("Department not found!");
                }
            } catch (SQLException e) {
                showMessage("Error searching department: " + e.getMessage());
            }
        } else if (ae.getSource() == btnNext) {
            new college.gui.awt.InstructorForm().setVisible(true);
            this.setVisible(false);
        }
    }

    private void showMessage(String message) {
        Dialog dialog = new Dialog(this, "Message", true);
        dialog.setLayout(new FlowLayout());
        dialog.setBounds(150, 150, 300, 150);
        Label lblMessage = new Label(message);
        Button btnOk = new Button("OK");
        btnOk.addActionListener(e -> dialog.dispose());
        dialog.add(lblMessage);
        dialog.add(btnOk);
        dialog.setVisible(true);
    }

    public static void main(String[] args) {
        DepartmentForm departmentForm = new DepartmentForm();
    }
}