package college.gui.awt;

import college.db.DatabaseConnection;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;

public class StudentForm extends Frame implements ActionListener {
    TextField txtStudentID, txtFname, txtLname, txtPhone;
    Label lblStudentID, lblFname, lblLname, lblPhone;
    Button btnInsert, btnUpdate, btnDelete, btnSearch, btnNext;
    TextArea tableDisplay;

    StudentForm() {
        setLayout(null);
        setBounds(0, 0, 500, 400);
        setTitle("Student Form");

        lblStudentID = new Label("Student ID:");
        lblStudentID.setBounds(50, 50, 80, 25);
        txtStudentID = new TextField();
        txtStudentID.setBounds(150, 50, 150, 25);

        lblFname = new Label("First Name:");
        lblFname.setBounds(50, 90, 80, 25);
        txtFname = new TextField();
        txtFname.setBounds(150, 90, 150, 25);

        lblLname = new Label("Last Name:");
        lblLname.setBounds(50, 130, 80, 25);
        txtLname = new TextField();
        txtLname.setBounds(150, 130, 150, 25);

        lblPhone = new Label("Phone:");
        lblPhone.setBounds(50, 170, 80, 25);
        txtPhone = new TextField();
        txtPhone.setBounds(150, 170, 150, 25);

        btnInsert = new Button("Insert");
        btnInsert.setBounds(50, 210, 60, 30);
        btnUpdate = new Button("Update");
        btnUpdate.setBounds(120, 210, 60, 30);
        btnDelete = new Button("Delete");
        btnDelete.setBounds(190, 210, 60, 30);
        btnSearch = new Button("Search");
        btnSearch.setBounds(260, 210, 60, 30);
        btnNext = new Button("Next");
        btnNext.setBounds(400, 50, 60, 30);

        tableDisplay = new TextArea();
        tableDisplay.setBounds(50, 250, 400, 120);
        tableDisplay.setEditable(false);

        add(lblStudentID);
        add(txtStudentID);
        add(lblFname);
        add(txtFname);
        add(lblLname);
        add(txtLname);
        add(lblPhone);
        add(txtPhone);
        add(btnInsert);
        add(btnUpdate);
        add(btnDelete);
        add(btnSearch);
        add(btnNext);
        add(tableDisplay);

        btnInsert.addActionListener(this);
        btnUpdate.addActionListener(this);
        btnDelete.addActionListener(this);
        btnSearch.addActionListener(this);
        btnNext.addActionListener(this);

        loadData();
        setVisible(true);

        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent we) {
                System.exit(0);
            }
        });
    }

    private void loadData() {
        tableDisplay.setText("");
        try (Connection conn = DatabaseConnection.getConnection()) {
            String sql = "SELECT * FROM Student";
            PreparedStatement stmt = conn.prepareStatement(sql);
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                String studentID = rs.getString("Student_ID");
                String fname = rs.getString("Fname");
                String lname = rs.getString("Lname");
                String phone = rs.getString("Phone");
                tableDisplay.append(studentID + "\t" + fname + "\t" + lname + "\t" + phone + "\n");
            }
        } catch (SQLException e) {
            showMessage("Error loading data: " + e.getMessage());
        }
    }

    private void clearFields() {
        txtStudentID.setText("");
        txtFname.setText("");
        txtLname.setText("");
        txtPhone.setText("");
    }

    @Override
    public void actionPerformed(ActionEvent ae) {
        if (ae.getSource() == btnInsert) {
            String studentID = txtStudentID.getText();
            String fname = txtFname.getText();
            String lname = txtLname.getText();
            String phone = txtPhone.getText();

            if (studentID.isEmpty() || fname.isEmpty() || lname.isEmpty() || phone.isEmpty()) {
                showMessage("Please fill all required fields");
                return;
            }

            try (Connection conn = DatabaseConnection.getConnection()) {
                String checkSql = "SELECT COUNT(*) FROM Student WHERE Student_ID = ?";
                PreparedStatement checkStmt = conn.prepareStatement(checkSql);
                checkStmt.setString(1, studentID);
                ResultSet rs = checkStmt.executeQuery();
                if (rs.next() && rs.getInt(1) > 0) {
                    showMessage("Student with ID '" + studentID + "' already exists!");
                    return;
                }
            } catch (SQLException e) {
                showMessage("Error checking student: " + e.getMessage());
                return;
            }

            try (Connection conn = DatabaseConnection.getConnection()) {
                String sql = "INSERT INTO Student (Student_ID, Fname, Lname, Phone) VALUES (?, ?, ?, ?)";
                PreparedStatement stmt = conn.prepareStatement(sql);
                stmt.setString(1, studentID);
                stmt.setString(2, fname);
                stmt.setString(3, lname);
                stmt.setString(4, phone);
                stmt.executeUpdate();
                showMessage("Student inserted successfully!");
                loadData();
                clearFields();
            } catch (SQLException e) {
                showMessage("Error inserting student: " + e.getMessage());
            }
        } else if (ae.getSource() == btnUpdate) {
            String studentID = txtStudentID.getText();
            String fname = txtFname.getText();
            String lname = txtLname.getText();
            String phone = txtPhone.getText();

            if (studentID.isEmpty() || fname.isEmpty() || lname.isEmpty() || phone.isEmpty()) {
                showMessage("Please fill all required fields");
                return;
            }

            try (Connection conn = DatabaseConnection.getConnection()) {
                String sql = "UPDATE Student SET Fname = ?, Lname = ?, Phone = ? WHERE Student_ID = ?";
                PreparedStatement stmt = conn.prepareStatement(sql);
                stmt.setString(1, fname);
                stmt.setString(2, lname);
                stmt.setString(3, phone);
                stmt.setString(4, studentID);
                int rows = stmt.executeUpdate();
                if (rows > 0) {
                    showMessage("Student updated successfully!");
                    loadData();
                    clearFields();
                } else {
                    showMessage("Student not found!");
                }
            } catch (SQLException e) {
                showMessage("Error updating student: " + e.getMessage());
            }
        } else if (ae.getSource() == btnDelete) {
            String studentID = txtStudentID.getText();

            if (studentID.isEmpty()) {
                showMessage("Please enter Student ID to delete");
                return;
            }

            try (Connection conn = DatabaseConnection.getConnection()) {
                String sql = "DELETE FROM Student WHERE Student_ID = ?";
                PreparedStatement stmt = conn.prepareStatement(sql);
                stmt.setString(1, studentID);
                int rows = stmt.executeUpdate();
                if (rows > 0) {
                    showMessage("Student deleted successfully!");
                    loadData();
                    clearFields();
                } else {
                    showMessage("Student not found!");
                }
            } catch (SQLException e) {
                showMessage("Error deleting student: " + e.getMessage());
            }
        } else if (ae.getSource() == btnSearch) {
            String studentID = txtStudentID.getText();

            if (studentID.isEmpty()) {
                loadData();
                return;
            }

            tableDisplay.setText("");
            try (Connection conn = DatabaseConnection.getConnection()) {
                String sql = "SELECT * FROM Student WHERE Student_ID = ?";
                PreparedStatement stmt = conn.prepareStatement(sql);
                stmt.setString(1, studentID);
                ResultSet rs = stmt.executeQuery();
                if (rs.next()) {
                    String fname = rs.getString("Fname");
                    String lname = rs.getString("Lname");
                    String phone = rs.getString("Phone");
                    tableDisplay.append(studentID + "\t" + fname + "\t" + lname + "\t" + phone + "\n");
                } else {
                    showMessage("Student not found!");
                }
            } catch (SQLException e) {
                showMessage("Error searching student: " + e.getMessage());
            }
        } else if (ae.getSource() == btnNext) {
            // استخدام DepartmentForm الجديدة في college.gui.awt
            new college.gui.awt.DepartmentForm().setVisible(true);
            this.setVisible(false);
        }
    }

    private void showMessage(String message) {
        Dialog dialog = new Dialog(this, "Message", true);
        dialog.setLayout(new FlowLayout());
        dialog.setBounds(150, 150, 300, 150);
        Label lblMessage = new Label(message);
        Button btnOk = new Button("OK");
        btnOk.addActionListener(e -> dialog.dispose());
        dialog.add(lblMessage);
        dialog.add(btnOk);
        dialog.setVisible(true);
    }

    public static void main(String[] args) {
        StudentForm studentForm = new StudentForm();
    }
}