package college.gui.awt;

import college.db.DatabaseConnection;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;

public class LoginForm extends Frame {
    Label lblUsername, lblPassword, lblRole;
    TextField txtUsername, txtPassword;
    Choice roleChoice;
    Button btnLogin;
    Image backgroundImage;

    LoginForm() {
        setLayout(null);
        setBounds(0, 0, 400, 300);
        setTitle("Login Form");

        // تحميل الصورة من نفس الـ package
        backgroundImage = Toolkit.getDefaultToolkit().getImage(getClass().getResource("login design.png"));

        lblUsername = new Label("Username:");
        lblUsername.setBounds(30, 80, 80, 25); // نزّلنا من y=50 لـ 80، ودخّلنا شمال من x=50 لـ 30
        txtUsername = new TextField();
        txtUsername.setBounds(130, 80, 150, 25); // نزّلنا من y=50 لـ 80، ودخّلنا شمال من x=150 لـ 130

        lblPassword = new Label("Password:");
        lblPassword.setBounds(30, 120, 80, 25); // نزّلنا من y=90 لـ 120، ودخّلنا شمال من x=50 لـ 30
        txtPassword = new TextField();
        txtPassword.setBounds(130, 120, 150, 25); // نزّلنا من y=90 لـ 120، ودخّلنا شمال من x=150 لـ 130
        txtPassword.setEchoChar('*');

        lblRole = new Label("Role:");
        lblRole.setBounds(30, 160, 80, 25); // نزّلنا من y=130 لـ 160، ودخّلنا شمال من x=50 لـ 30
        roleChoice = new Choice();
        roleChoice.add("Department");
        roleChoice.add("Instructor");
        roleChoice.add("Student");
        roleChoice.setBounds(130, 160, 150, 25); // نزّلنا من y=130 لـ 160، ودخّلنا شمال من x=150 لـ 130

        btnLogin = new Button("Login");
        btnLogin.setBounds(130, 200, 80, 30); // نزّلنا من y=170 لـ 200، ودخّلنا شمال من x=150 لـ 130

        add(lblUsername);
        add(txtUsername);
        add(lblPassword);
        add(txtPassword);
        add(lblRole);
        add(roleChoice);
        add(btnLogin);

        btnLogin.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent ae) {
                String username = txtUsername.getText();
                String password = txtPassword.getText();
                String role = roleChoice.getSelectedItem();

                if (username.isEmpty() || password.isEmpty()) {
                    showMessage("Please enter username and password");
                    return;
                }

                try (Connection conn = DatabaseConnection.getConnection()) {
                    String sql = "SELECT Entity_ID FROM Users WHERE Username = ? AND Password = ? AND Role = ?";
                    PreparedStatement stmt = conn.prepareStatement(sql);
                    stmt.setString(1, username);
                    stmt.setString(2, password);
                    stmt.setString(3, role);
                    ResultSet rs = stmt.executeQuery();

                    if (rs.next()) {
                        switch (role) {
                            case "Department" -> new DepartmentForm().setVisible(true);
                            case "Instructor" -> new InstructorForm().setVisible(true);
                            case "Student" -> new StudentForm().setVisible(true);
                        }
                        dispose();
                    } else {
                        showMessage("Invalid username, password, or role");
                    }
                } catch (SQLException e) {
                    showMessage("Error: " + e.getMessage());
                }
            }
        });

        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent we) {
                System.exit(0);
            }
        });

        setVisible(true);
    }

    @Override
    public void paint(Graphics g) {
        // رسم الصورة كخلفية
        if (backgroundImage != null) {
            g.drawImage(backgroundImage, 0, 0, getWidth(), getHeight(), this);
        }
        // استدعاء الـ paint الأصلي عشان يرسم باقي العناصر (Labels, TextFields, إلخ)
        super.paint(g);
    }

    private void showMessage(String message) {
        Dialog dialog = new Dialog(this, "Message", true);
        dialog.setLayout(new FlowLayout());
        dialog.setBounds(150, 150, 300, 150);
        Label lblMessage = new Label(message);
        Button btnOk = new Button("OK");
        btnOk.addActionListener(e -> dialog.dispose());
        dialog.add(lblMessage);
        dialog.add(btnOk);
        dialog.setVisible(true);
    }

    public static void main(String[] args) {
        LoginForm loginForm = new LoginForm();
    }
}