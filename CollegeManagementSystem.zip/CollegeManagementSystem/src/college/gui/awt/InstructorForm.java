package college.gui.awt;

import college.db.DatabaseConnection;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;

public class InstructorForm extends Frame implements ActionListener {
    TextField txtInstructorID, txtFname, txtLname, txtPhone, txtDName;
    Label lblInstructorID, lblFname, lblLname, lblPhone, lblDName;
    Button btnInsert, btnUpdate, btnDelete, btnSearch, btnNext;
    TextArea tableDisplay;

    InstructorForm() {
        setLayout(null);
        setBounds(0, 0, 500, 450);
        setTitle("Instructor Form");

        lblInstructorID = new Label("Instructor ID:");
        lblInstructorID.setBounds(50, 50, 80, 25);
        txtInstructorID = new TextField();
        txtInstructorID.setBounds(150, 50, 150, 25);

        lblFname = new Label("First Name:");
        lblFname.setBounds(50, 90, 80, 25);
        txtFname = new TextField();
        txtFname.setBounds(150, 90, 150, 25);

        lblLname = new Label("Last Name:");
        lblLname.setBounds(50, 130, 80, 25);
        txtLname = new TextField();
        txtLname.setBounds(150, 130, 150, 25);

        lblPhone = new Label("Phone:");
        lblPhone.setBounds(50, 170, 80, 25);
        txtPhone = new TextField();
        txtPhone.setBounds(150, 170, 150, 25);

        lblDName = new Label("Department:");
        lblDName.setBounds(50, 210, 80, 25);
        txtDName = new TextField();
        txtDName.setBounds(150, 210, 150, 25);

        btnInsert = new Button("Insert");
        btnInsert.setBounds(50, 250, 60, 30);
        btnUpdate = new Button("Update");
        btnUpdate.setBounds(120, 250, 60, 30);
        btnDelete = new Button("Delete");
        btnDelete.setBounds(190, 250, 60, 30);
        btnSearch = new Button("Search");
        btnSearch.setBounds(260, 250, 60, 30);
        btnNext = new Button("Next");
        btnNext.setBounds(400, 50, 60, 30);

        tableDisplay = new TextArea();
        tableDisplay.setBounds(50, 290, 400, 150);
        tableDisplay.setEditable(false);

        add(lblInstructorID);
        add(txtInstructorID);
        add(lblFname);
        add(txtFname);
        add(lblLname);
        add(txtLname);
        add(lblPhone);
        add(txtPhone);
        add(lblDName);
        add(txtDName);
        add(btnInsert);
        add(btnUpdate);
        add(btnDelete);
        add(btnSearch);
        add(btnNext);
        add(tableDisplay);

        btnInsert.addActionListener(this);
        btnUpdate.addActionListener(this);
        btnDelete.addActionListener(this);
        btnSearch.addActionListener(this);
        btnNext.addActionListener(this);

        loadData();
        setVisible(true);

        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent we) {
                System.exit(0);
            }
        });
    }

    private void loadData() {
        tableDisplay.setText("");
        try (Connection conn = DatabaseConnection.getConnection()) {
            String sql = "SELECT * FROM Instructor";
            PreparedStatement stmt = conn.prepareStatement(sql);
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                String instructorID = rs.getString("Instructor_ID");
                String fname = rs.getString("Fname");
                String lname = rs.getString("Lname");
                String phone = rs.getString("Phone");
                String dName = rs.getString("D_Name");
                tableDisplay.append(instructorID + "\t" + fname + "\t" + lname + "\t" + phone + "\t" + dName + "\n");
            }
        } catch (SQLException e) {
            showMessage("Error loading data: " + e.getMessage());
        }
    }

    private void clearFields() {
        txtInstructorID.setText("");
        txtFname.setText("");
        txtLname.setText("");
        txtPhone.setText("");
        txtDName.setText("");
    }

    @Override
    public void actionPerformed(ActionEvent ae) {
        if (ae.getSource() == btnInsert) {
            String instructorID = txtInstructorID.getText();
            String fname = txtFname.getText();
            String lname = txtLname.getText();
            String phone = txtPhone.getText();
            String dName = txtDName.getText();

            if (instructorID.isEmpty() || fname.isEmpty() || lname.isEmpty() || phone.isEmpty() || dName.isEmpty()) {
                showMessage("Please fill all required fields");
                return;
            }

            try (Connection conn = DatabaseConnection.getConnection()) {
                String checkSql = "SELECT COUNT(*) FROM Instructor WHERE Instructor_ID = ?";
                PreparedStatement checkStmt = conn.prepareStatement(checkSql);
                checkStmt.setString(1, instructorID);
                ResultSet rs = checkStmt.executeQuery();
                if (rs.next() && rs.getInt(1) > 0) {
                    showMessage("Instructor with ID '" + instructorID + "' already exists!");
                    return;
                }
            } catch (SQLException e) {
                showMessage("Error checking instructor: " + e.getMessage());
                return;
            }

            try (Connection conn = DatabaseConnection.getConnection()) {
                String checkDeptSql = "SELECT COUNT(*) FROM Department WHERE D_Name = ?";
                PreparedStatement checkDeptStmt = conn.prepareStatement(checkDeptSql);
                checkDeptStmt.setString(1, dName);
                ResultSet rs = checkDeptStmt.executeQuery();
                if (rs.next() && rs.getInt(1) == 0) {
                    showMessage("Department with name '" + dName + "' does not exist!");
                    return;
                }
            } catch (SQLException e) {
                showMessage("Error checking department: " + e.getMessage());
                return;
            }

            try (Connection conn = DatabaseConnection.getConnection()) {
                String sql = "INSERT INTO Instructor (Instructor_ID, Fname, Lname, Phone, D_Name) VALUES (?, ?, ?, ?, ?)";
                PreparedStatement stmt = conn.prepareStatement(sql);
                stmt.setString(1, instructorID);
                stmt.setString(2, fname);
                stmt.setString(3, lname);
                stmt.setString(4, phone);
                stmt.setString(5, dName);
                stmt.executeUpdate();
                showMessage("Instructor inserted successfully!");
                loadData();
                clearFields();
            } catch (SQLException e) {
                showMessage("Error inserting instructor: " + e.getMessage());
            }
        } else if (ae.getSource() == btnUpdate) {
            String instructorID = txtInstructorID.getText();
            String fname = txtFname.getText();
            String lname = txtLname.getText();
            String phone = txtPhone.getText();
            String dName = txtDName.getText();

            if (instructorID.isEmpty() || fname.isEmpty() || lname.isEmpty() || phone.isEmpty() || dName.isEmpty()) {
                showMessage("Please fill all required fields");
                return;
            }

            try (Connection conn = DatabaseConnection.getConnection()) {
                String checkDeptSql = "SELECT COUNT(*) FROM Department WHERE D_Name = ?";
                PreparedStatement checkDeptStmt = conn.prepareStatement(checkDeptSql);
                checkDeptStmt.setString(1, dName);
                ResultSet rs = checkDeptStmt.executeQuery();
                if (rs.next() && rs.getInt(1) == 0) {
                    showMessage("Department with name '" + dName + "' does not exist!");
                    return;
                }
            } catch (SQLException e) {
                showMessage("Error checking department: " + e.getMessage());
                return;
            }

            try (Connection conn = DatabaseConnection.getConnection()) {
                String sql = "UPDATE Instructor SET Fname = ?, Lname = ?, Phone = ?, D_Name = ? WHERE Instructor_ID = ?";
                PreparedStatement stmt = conn.prepareStatement(sql);
                stmt.setString(1, fname);
                stmt.setString(2, lname);
                stmt.setString(3, phone);
                stmt.setString(4, dName);
                stmt.setString(5, instructorID);
                int rows = stmt.executeUpdate();
                if (rows > 0) {
                    showMessage("Instructor updated successfully!");
                    loadData();
                    clearFields();
                } else {
                    showMessage("Instructor not found!");
                }
            } catch (SQLException e) {
                showMessage("Error updating instructor: " + e.getMessage());
            }
        } else if (ae.getSource() == btnDelete) {
            String instructorID = txtInstructorID.getText();

            if (instructorID.isEmpty()) {
                showMessage("Please enter Instructor ID to delete");
                return;
            }

            try (Connection conn = DatabaseConnection.getConnection()) {
                String sql = "DELETE FROM Instructor WHERE Instructor_ID = ?";
                PreparedStatement stmt = conn.prepareStatement(sql);
                stmt.setString(1, instructorID);
                int rows = stmt.executeUpdate();
                if (rows > 0) {
                    showMessage("Instructor deleted successfully!");
                    loadData();
                    clearFields();
                } else {
                    showMessage("Instructor not found!");
                }
            } catch (SQLException e) {
                showMessage("Error deleting instructor: " + e.getMessage());
            }
        } else if (ae.getSource() == btnSearch) {
            String instructorID = txtInstructorID.getText();

            if (instructorID.isEmpty()) {
                loadData();
                return;
            }

            tableDisplay.setText("");
            try (Connection conn = DatabaseConnection.getConnection()) {
                String sql = "SELECT * FROM Instructor WHERE Instructor_ID = ?";
                PreparedStatement stmt = conn.prepareStatement(sql);
                stmt.setString(1, instructorID);
                ResultSet rs = stmt.executeQuery();
                if (rs.next()) {
                    String fname = rs.getString("Fname");
                    String lname = rs.getString("Lname");
                    String phone = rs.getString("Phone");
                    String dName = rs.getString("D_Name");
                    tableDisplay.append(instructorID + "\t" + fname + "\t" + lname + "\t" + phone + "\t" + dName + "\n");
                } else {
                    showMessage("Instructor not found!");
                }
            } catch (SQLException e) {
                showMessage("Error searching instructor: " + e.getMessage());
            }
        } else if (ae.getSource() == btnNext) {
            new college.gui.awt.StudentForm().setVisible(true);
            this.setVisible(false);
        }
    }

    private void showMessage(String message) {
        Dialog dialog = new Dialog(this, "Message", true);
        dialog.setLayout(new FlowLayout());
        dialog.setBounds(150, 150, 300, 150);
        Label lblMessage = new Label(message);
        Button btnOk = new Button("OK");
        btnOk.addActionListener(e -> dialog.dispose());
        dialog.add(lblMessage);
        dialog.add(btnOk);
        dialog.setVisible(true);
    }

    public static void main(String[] args) {
        InstructorForm instructorForm = new InstructorForm();
    }
}